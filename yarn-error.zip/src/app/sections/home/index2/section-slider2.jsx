import { NavLink } from "react-router-dom";
import { register } from "swiper/element/bundle";
import { useState, useEffect } from "react";
import {
  DiPython,
  DiJava,
  DiPhp,
  DiDotnet,
  DiAndroid,
} from "react-icons/di";
import {
  SiFlutter,
  SiSelenium,
  SiDatabricks,
  SiGoogleads,
  SiSalesforce,
  SiKalilinux,
  SiMongodb,
  SiDeviantart,
  SiFigma,
  SiExpress,
} from "react-icons/si";
import { FaReact, FaAngular, FaNodeJs } from "react-icons/fa";
import "./SectionSlider2.css";

register();

/* ✅ PUBLIC URL HELPER */
const publicUrlFor = (path) => process.env.PUBLIC_URL + "/" + path;

/* ✅ IMAGE PATH (CORRECT) */
const homepage = publicUrlFor("assets/images/homep/homepage.jpg");

function SectionSlider2() {
  const [mode, setMode] = useState("online");

  useEffect(() => {
    const observerOptions = { threshold: 0.1 };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("show-card");
        }
      });
    }, observerOptions);

    const hiddenElements = document.querySelectorAll(".course-card-hidden");
    hiddenElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  /* ===== COURSES ARRAY WITH PATHS ===== */
  const courses = [
    {
      name: "Python FullStack",
      icon: <DiPython size={50} color="#3776AB" />,
      desc: "Our Python Fullstack Course contains Fundamentals of Python, Frontend Technologies (HTML, CSS, JS, Angular - intro), and Django Framework with SQL Integration.",
      path: "/courses/python-fullstack-development",
    },
    {
      name: "Java FullStack",
      icon: <DiJava size={50} color="#007396" />,
      desc: "This Java Fullstack Course includes Core Java, JDBC, JSP/Servlet, Spring Framework, and Frontend Technologies with SQL Integration.",
      path: "/courses/java-fullstack-development",
    },
    {
      name: "PHP FullStack",
      icon: <DiPhp size={50} color="#777BB4" />,
      desc: "Learn PHP Fullstack from basics to advanced with MySQL, Laravel Framework, and essential frontend technologies.",
      path: "/courses/php-fullstack-development",
    },
    {
      name: "Flutter Development",
      icon: <SiFlutter size={45} color="#02569B" />,
      desc: "Build cross-platform mobile apps using Flutter and Dart with real-time UI rendering and backend connectivity.",
      path: "/courses/flutter-development",
    },
    {
      name: "Software Testing",
      icon: <SiSelenium size={45} color="#43B02A" />,
      desc: "Learn manual and automation testing with tools like Selenium, JUnit, and Bug Tracking Systems.",
      path: "/courses/software-testing",
    },
    {
      name: "Data Science",
      icon: <SiDatabricks size={45} color="#E25A1E" />,
      desc: "Gain hands-on experience in Python, Pandas, ML Algorithms, and Visualization using tools like Tableau.",
      path: "/courses/data-science-ai",
    },
    {
      name: "Digital Marketing",
      icon: <SiGoogleads size={45} color="#4285F4" />,
      desc: "This course includes SEO, SEM, Social Media Marketing, Analytics, and Tools like Canva & Google Ads.",
      path: "/courses/digital-marketing-course",
    },
    {
      name: "Salesforce",
      icon: <SiSalesforce size={45} color="#00A1E0" />,
      desc: "Learn CRM development and automation with Salesforce Admin and Apex programming.",
      path: "/courses/salesforce-testing",
    },
    {
      name: "Cyber Security",
      icon: <SiKalilinux size={45} color="#557C94" />,
      desc: "Understand ethical hacking, network security, and penetration testing with practicals.",
      path: "/courses/cybersecurity",
    },
    {
      name: ".NET FullStack",
      icon: <DiDotnet size={50} color="#512BD4" />,
      desc: "Our .NET Fullstack Course covers C#, ASP.NET MVC, SQL Server, and Frontend Tools like HTML, CSS & JS.",
      path: "/courses/dotnet-fullstack-development",
    },
    {
      name: "MERN Stack",
      icon: (
        <div style={{ display: "flex", gap: "4px", alignItems: "center" }}>
          <SiMongodb size={22} color="#47A248" />
          <SiExpress size={22} color="#000" />
          <FaReact size={22} color="#61DAFB" />
          <FaNodeJs size={22} color="#339933" />
        </div>
      ),
      desc: "The MERN Stack course covers MongoDB, Express.js, React.js, and Node.js for fullstack web application development.",
      path: "/courses/mern-fullstack-development",
    },
    {
      name: "MEAN Stack",
      icon: <FaAngular size={45} color="#DD0031" />,
      desc: "This course offers MEAN Stack development using MongoDB, Express.js, Angular, and Node.js for robust web apps.",
      path: "/courses/mean-fullstack-development",
    },
    {
      name: "DevOps",
      icon: <SiDeviantart size={45} color="#000" />,
      desc: "Understand DevOps lifecycle using Jenkins, Docker, Kubernetes, Git, and CI/CD tools.",
      path: "/courses/devops",
    },
    {
      name: "UI/UX",
      icon: <SiFigma size={45} color="#F24E1E" />,
      desc: "Learn the fundamentals of UI/UX with tools like Figma and Adobe XD, focusing on user-centered design and usability.",
      path: "/courses/ui-ux-developer",
    },
    {
      name: "React.js",
      icon: <FaReact size={45} color="#61DAFB" />,
      desc: "Dive into React.js to build interactive UIs with JSX, Hooks, Routing, and real-time project integration.",
      path: "/courses/reactjs-development",
    },
    {
      name: "Android (Kotlin, Java)",
      icon: <DiAndroid size={45} color="#3DDC84" />,
      desc: "Learn Android development using Kotlin, covering UI design, SQLite, and Firebase integration.",
      path: "/courses/android-development",
    },
    {
      name: "Angular",
      icon: <FaAngular size={45} color="#DD0031" />,
      desc: "Learn Angular from basics to services and modules to build structured and scalable single-page applications.",
      path: "/courses/angular-development",
    },
    {
      name: "ASP.NET",
      icon: <DiDotnet size={45} color="#512BD4" />,
      desc: "Our .NET Fullstack Course covers C#, ASP.NET MVC, SQL Server, and Frontend Tools like HTML, CSS & JS.",
      path: "/courses/dotnet-fullstack-development",
    },
    {
      name: "C Programming",
      icon: <DiDotnet size={45} color="#FF5733" />,
      desc: "Learn C Programming from basics to advanced concepts including pointers, arrays, and memory management.",
      path: "/courses/c-programming-course",
    },
    {
      name: "Advance Java",
      icon: <DiJava size={45} color="#007396" />,
      desc: "Advance Java course covers multithreading, collections, JDBC, and Spring Boot for enterprise applications.",
      path: "/courses/advance-java-course",
    },
  ];

  return (
    <>
      {/* HERO SLIDER */}
      <div className="sx-bnr-2-wrap-outer home-2-slider">
        <swiper-container loop="false">
          <swiper-slide
            style={{
              backgroundImage: `url(${homepage})`,
              height: "450px",
              backgroundSize: "cover",
              backgroundPosition: "center",
              position: "relative",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                background: "rgba(0,0,0,0.7)",
                zIndex: 1,
              }}
            />

            <div
              className="container h-100"
              style={{ position: "relative", zIndex: 2 }}
            >
              <div className="main-content-container">
                <h3
                  className="text-white"
                  style={{
                    fontSize: "18px",
                    paddingTop: "10px",
                    marginBottom: "100px",
                    textAlign: "center",
                  }}
                >
                  BEST IT TRAINING & PLACEMENT INSTITUTE IN PUNE
                </h3>

                <h1
                  style={{
                    color: "#FFB400",
                    fontSize: "42px",
                    fontWeight: "bold",
                    paddingBottom: "110px",
                    marginBottom: "20px",
                    textAlign: "center",
                    position: "relative",
                    top: "-90px",
                  }}
                >
                  ORANGE ITECH
                </h1>

                <h2
                  className="text-white"
                  style={{
                    position: "relative",
                    top: "-150px",
                    textAlign: "center",
                    fontSize: "2rem",
                    lineHeight: "1.4",
                  }}
                >
                  Build Job-Ready IT Skills with Expert Training & Guaranteed Career
                  Support
                </h2>

                <NavLink to="/contact-us" className="orange-btn">
                  Book a Free Career Counseling Session
                </NavLink>
              </div>
            </div>
          </swiper-slide>
        </swiper-container>
      </div>

      {/* COURSES SECTION */}
      <div className="course-section">
        <h2
          className="course-title"
          style={{
            textAlign: "center",
            marginTop: "-30px",
            fontSize: "2.5rem",
            fontWeight: "bold",
          }}
        >
          INDUSTRY-FOCUSED IT COURSES IN PUNE
        </h2>
        <h3 className="text-center">
          We Provide a wide range of job-oriented IT courses to match different
          career goals
        </h3>
        <h4 className="text-center">EXPLORE OUR COURSES </h4>

        <div className="mode-toggle-container">
          <div className="toggle-box">
            <button
              className={`toggle-btn ${mode === "online" ? "active" : ""}`}
              onClick={() => setMode("online")}
            >
              Online
            </button>
            <button
              className={`toggle-btn ${mode === "offline" ? "active" : ""}`}
              onClick={() => setMode("offline")}
            >
              Offline
            </button>
          </div>
        </div>

        <div className="courses-grid">
          {courses.map((course, index) => (
            <div
              key={index}
              className="course-card course-card-hidden"
              style={{ transitionDelay: `${(index % 3) * 0.15}s` }}
            >
              <div className="icon-box">{course.icon}</div>
              <h4 className="course-name">{course.name}</h4>
              <p className="course-desc">{course.desc}</p>
              <div className="card-buttons">
                <NavLink to="/enroll" className="btn-enroll">
                  Enroll Now
                </NavLink>
                <NavLink to={course.path} className="btn-explore">
                  Explore Now
                </NavLink>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default SectionSlider2;
