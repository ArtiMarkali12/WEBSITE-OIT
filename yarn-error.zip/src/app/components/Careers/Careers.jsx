import React, { useState } from 'react';


import './Careers.css';
import ApplyJobForm from './ApplyJobForm.jsx'; // Import the ApplyJobForm component

import { 
  FaAndroid, FaReact, FaPython, FaPhp, FaJava, FaNodeJs, FaLaravel, FaPaintBrush, FaBolt, FaPuzzlePiece
} from 'react-icons/fa';
import { SiFlutter, SiDotnet, SiDigitalocean } from 'react-icons/si';
import { FaCheckCircle, FaMapMarkerAlt, FaBuilding, FaMoneyBillWave, FaBriefcase } from "react-icons/fa";

import { FiCheck } from "react-icons/fi";





/* ================= ICON MAP ================= */
const jobIcons = {
  "Android Developer": <FaAndroid size={30} color="#8dd692ff" />,
  "UI/UX Designer": <FaPaintBrush size={30} color="#f07339ff" />,
  "Flutter Developer": <SiFlutter size={30} color="#96ccf5ff" />,
  "Java Developer": <FaJava size={30} color="#f55626ff" />,
  "PHP Developer": <FaPhp size={30} color="#8dd692ff" />,
  "Digital Marketing Intern": <SiDigitalocean size={30} color="#66c0f4ff" />,
  ".NET Developer": <SiDotnet size={30} color="#46e815ff" />,
  "Python Developer": <FaPython size={30} color="#F57F17" />,
  "React Developer": <FaReact size={30} color="#1565C0" />,
  "Node Developer": <FaNodeJs size={30} color="#33691E" />,
  "Laravel Developer": <FaLaravel size={30} color="#B71C1C" />
};

// 📦 JSON DATA — as provided with additional jobs from reference images
const jobListings = [
  {
    id: 1,
    title: "Android Developer",
    type: "Internship",
    eligibility: "Build and maintain Android apps with modern UI and performance. Eligibility: BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 pass-outs",
    requirements: [
      "Proficiency in Java/Kotlin",
      "Knowledge of Android SDK, RESTful APIs",
      "Familiarity with MVVM or MVP architecture"
    ],
    stipend: "₹10,000/month for 3 months, followed by a permanent position with ₹2.2 LPA CTC",
    location: "Pune, India",
    experience: "0-1 Years",
    isHiring: true
  },
  {
    id: 2,
    title: "UI/UX Designer",
    type: "Internship",
    eligibility: "Design user-friendly interfaces and develop responsive layouts. Eligibility: BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 pass-outs",
    requirements: [
      "Figma, Adobe XD, or similar tools",
      "HTML, CSS, JavaScript basics",
      "Understanding of mobile-first and responsive design"
    ],
    stipend: "₹10,000/month for 3 months, followed by a permanent position with ₹2.2 LPA CTC",
    location: "Pune, India",
    experience: "0-1 Years",
    isHiring: true
  },
  {
    id: 3,
    title: "Flutter Developer",
    type: "Internship",
    eligibility: "Create high-performance cross-platform apps using Flutter & Dart. Eligibility: BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 pass-outs",
    requirements: [
      "Strong knowledge of Flutter and Dart",
      "Understanding of widgets and state management",
      "Integration of APIs and third-party libraries"
    ],
    stipend: "₹10,000/month for 3 months, followed by a permanent position with ₹2.2 LPA CTC",
    location: "Pune, India",
    experience: "0-1 Years",
    isHiring: true
  },
  {
    id: 4,
    title: "Java Developer",
    type: "Internship",
    eligibility: "Develop scalable backend applications using Core Java and JDBC. Eligibility: BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 pass-outs",
    requirements: [
      "Core Java, OOP's concepts",
      "JDBC, Servlets, JSP",
      "SQL and relational databases"
    ],
    stipend: "₹10,000/month for 3 months, followed by a permanent position with ₹2.2 LPA CTC",
    location: "Pune, India",
    experience: "0-1 Years",
    isHiring: true
  },
  {
    id: 5,
    title: "PHP Developer",
    type: "Internship",
    eligibility: "Build dynamic web applications using PHP and MySQL. Eligibility: BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 pass-outs",
    requirements: [
      "Core PHP, MySQL",
      "HTML, CSS, JavaScript",
      "Frameworks like Laravel (Bonus)"
    ],
    stipend: "₹10,000/month for 3 months, followed by a permanent position with ₹2.2 LPA CTC",
    location: "Pune, India",
    experience: "0-1 Years",
    isHiring: true
  },
  {
    id: 6,
    title: "Digital Marketing Intern",
    type: "Internship",
    eligibility: "Assist in SEO/SEM, Paid Ads, social media, and online campaign management to grow brand visibility.",
    requirements: [
      "SEO/SEM, Email Marketing, Content Writing",
      "Wordpress Development, Automation",
      "Social Media & Graphic Design"
    ],
    stipend: "₹10,000/month for 3 months, followed by a permanent position with ₹2.2 LPA CTC",
    location: "Pune, India",
    experience: "0-1 Years",
    isHiring: true
  },
  // JobAtOrange examples - Added from reference images
  {
    id: 7,
    title: ".NET Developer",
    type: "JobAtOrange",
    eligibility: "Final-year or recent grads in BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 passouts",
    position: "Position: .NET Developer",
    company: "Company: Nimap Infotech, Mumbai",
    location: "Location: Mumbai",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 8,
    title: "Java Developer",
    type: "JobAtOrange",
    eligibility: "Final-year or recent grads in BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 passouts",
    position: "Position: Java Developer",
    company: "Company: Nimap Infotech, Mumbai",
    location: "Location: Mumbai",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 9,
    title: "PHP Developer",
    type: "JobAtOrange",
    eligibility: "Final-year or recent grads in BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 passouts",
    position: "Position: PHP Developer",
    company: "Company: Nimap Infotech, Mumbai",
    location: "Location: Mumbai",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 10,
    title: "PHP Developer",
    type: "JobAtOrange",
    eligibility: "Design and develop dynamic web applications using PHP, MySQL, and related frameworks.",
    position: "Position: PHP Developer",
    company: "Company: Technologia Pvt Ltd.",
    location: "Location: Washim",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 11,
    title: "Python Developer",
    type: "JobAtOrange",
    eligibility: "Final-year or recent grads in BCA, BCS, BSc (CS), MCA, MCS – 2024/2025 passouts",
    position: "Position: Python Developer",
    company: "Company: Orange Itech",
    location: "Location: Pune",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 12,
    title: "Python Developer",
    type: "JobAtOrange",
    eligibility: "Develop and maintain Python-based applications, APIs, and backend systems.",
    position: "Position: Python Developer",
    company: "Company: Technologia Pvt Ltd",
    location: "Location: Washim",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 13,
    title: "React Developer",
    type: "JobAtOrange",
    eligibility: "Build dynamic user interfaces using React.js with a focus on performance and responsive design.",
    position: "Position: React Developer",
    company: "Company: Technologia Pvt. Ltd",
    location: "Location: Washim",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 14,
    title: "Node Developer",
    type: "JobAtOrange",
    eligibility: "Develop scalable backend services and APIs using Node.js and related frameworks.",
    position: "Position: Node Developer",
    company: "Company: Technologia Pvt. Ltd",
    location: "Location: Washim",
    salary: "Salary: ₹3.5 LPA",
    isHiring: true
  },
  {
    id: 15,
    title: "Laravel Developer",
    type: "JobAtOrange",
    eligibility: "Proficient in Laravel in skills with PHP, MVC architecture rest APIs, Eloquent ORM, MYSQL, Blade templating",
    position: "Position: Laravel Developer (2)",
    company: "Company: Orangeitech",
    location: "Location: Malad ",
    salary: "Salary: ₹4-6 LPA",
    isHiring: true
  },
  {
    id: 16,
    title: "Flutter Developer",
    type: "JobAtOrange",
    eligibility: "Proficient in Flutter, Dart, State management, Database, Git & Testing",
    position: "Position: Flutter Developer (2)",
    company: "Company: Orangeitech",
    location: "Location: Malad ",
    salary: "Salary: ₹4-6 LPA",
    isHiring: true
  }
];

// 🎨 JobCard Component
const JobCard = ({ job, onApplyClick }) => {
  return (
    <div className="job-card">
      
      <div className="card-header">
        {/* Hiring Ribbon - appears in top right corner */}
        {job.isHiring && (
          <div className="ribbon">HIRING!</div>
        )}
        <div className="icon-wrapper">
          {jobIcons[job.title] || <FaBolt size={30} color="#555" />}
        </div>
        <h2>{job.title}</h2>
      </div>

      <div className="card-body">
        <p className="eligibility">{job.eligibility}</p>

        {job.requirements && job.requirements.map((req, i) => (
          <div key={i} className="requirement-item">
           <span className="req-icon"><FiCheck /></span>

            <span>{req}</span>
          </div>
        ))}

        {job.position && (
          <div className="requirement-item">
            <span className="req-icon"><FaCheckCircle /></span>

            <span>{job.position}</span>
          </div>
        )}

        {job.company && (
          <div className="requirement-item">
           <span className="req-icon"><FaBuilding /></span>

            <span>{job.company}</span>
          </div>
        )}

        {job.location && (
          <div className="requirement-item">
            <span className="req-icon"><FaMapMarkerAlt /></span>

            <span>{job.location}</span>
          </div>
        )}

        {job.salary && (
          <div className="requirement-item">
        <span className="req-icon"><FaMoneyBillWave /></span>

            <span>{job.salary}</span>
          </div>
        )}

        {job.stipend && (
          <div className="requirement-item">
       <span className="req-icon"><FaMoneyBillWave /></span>

            <span>{job.stipend}</span>
          </div>
        )}

        <div className="card-actions">
          <button className="apply-btn" onClick={() => onApplyClick(job.title)}>
            Apply Now
          </button>
        </div>

        <div className="card-footer">
         <span className="location"><FaMapMarkerAlt /> {job.location || "Pune, India"}</span>

         <span className="type"><FaBriefcase /> {job.type}</span>

          <span className="experience"><FaCheckCircle /> {job.experience || "0-1 Years"}</span>

        </div>
      </div>
    </div>
  );
};

// 🧩 Main Component
const Careers = () => {
  const [isApplyFormOpen, setIsApplyFormOpen] = useState(false);
  const [selectedJobTitle, setSelectedJobTitle] = useState('');

  const handleApplyClick = (jobTitle) => {
    setSelectedJobTitle(jobTitle);
    setIsApplyFormOpen(true);
  };

  const handleCloseApplyForm = () => {
    setIsApplyFormOpen(false);
    setSelectedJobTitle('');
  };

  return (
    <div className="career-page-container">
      <div className="container">
        <header className="page-header">
          <h1>Join the Future of Tech – Careers at Orange ITech</h1>
        </header>

        <div className="section-title">#Internships</div>
        <div className="row">
          {jobListings.filter(j => j.type === "Internship").map(job => (
            <div key={job.id} className="col-md-4 mb-4">
              <JobCard job={job} onApplyClick={handleApplyClick} />
            </div>
          ))}
        </div>

        <div className="section-title">#JobAtOrange</div>
        <div className="row">
          {jobListings.filter(j => j.type === "JobAtOrange").map(job => (
            <div key={job.id} className="col-md-4 mb-4">
              <JobCard job={job} onApplyClick={handleApplyClick} />
            </div>
          ))}
        </div>
      </div>

      {/* Apply Job Form Modal */}
      {isApplyFormOpen && (
        <ApplyJobForm 
          isOpen={isApplyFormOpen} 
          onClose={handleCloseApplyForm} 
          jobTitle={selectedJobTitle}
        />
      )}
    </div>
  );
};

export default Careers;