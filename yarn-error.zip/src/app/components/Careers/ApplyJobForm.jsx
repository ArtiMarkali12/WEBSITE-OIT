import React, { useState } from "react";
import "./ApplyJobForm.css";

const ApplyJobForm = ({ isOpen, onClose, jobTitle }) => {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    country: "",
    coverLetter: "",
    file: null,
  });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append("fullName", formData.fullName);
    data.append("email", formData.email);
    data.append("phone", formData.phone);
    data.append("country", formData.country);
    data.append("coverLetter", formData.coverLetter);
    if (formData.file) data.append("resume", formData.file);
    data.append("jobTitle", jobTitle);

    fetch("https://your-backend-api.com/apply", {
      method: "POST",
      body: data,
    })
      .then((res) => res.json())
      .then(() => {
        alert("Application submitted successfully!");
        onClose();
      })
      .catch(() => {
        alert("Something went wrong!");
      });
  };

  if (!isOpen) return null;

  return (
    <div className="apply-job-overlay">
      <div className="apply-job-popup">
        <button className="close-btn" onClick={onClose}>✖</button>
        <h2>Apply for {jobTitle}</h2>

        <form onSubmit={handleSubmit}>

          {/* Full Name */}
          <div className="input-group">
            <div className="input-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff7a00" strokeWidth="2">
                <circle cx="12" cy="8" r="4" />
                <path d="M4 20c0-4 16-4 16 0" />
              </svg>
            </div>
            <input type="text" name="fullName" placeholder="Enter Full Name" value={formData.fullName} onChange={handleChange} required />
          </div>

          {/* Email */}
          <div className="input-group">
            <div className="input-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff7a00" strokeWidth="2">
                <rect x="3" y="5" width="18" height="14" rx="2" />
                <path d="M3 7l9 6 9-6" />
              </svg>
            </div>
            <input type="email" name="email" placeholder="Enter Your Email" value={formData.email} onChange={handleChange} required />
          </div>

          {/* Phone */}
          <div className="input-group">
            <div className="input-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff7a00" strokeWidth="2">
                <path d="M22 16.92v3a2 2 0 01-2.18 2A19.7 19.7 0 012.18 4.18 2 2 0 014 2h3a2 2 0 012 1.72c.12.96.3 1.9.54 2.8a2 2 0 01-.45 2.11L8.1 9.9a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.9.24 1.84.42 2.8.54A2 2 0 0122 16.92z"/>
              </svg>
            </div>
            <input type="tel" name="phone" placeholder="Enter Your Phone Number" value={formData.phone} onChange={handleChange} required />
          </div>

          {/* Country */}
          <div className="input-group">
            <select name="country" value={formData.country} onChange={handleChange} required>
              <option value="">Select your country</option>
              <option value="India">India</option>
              <option value="USA">USA</option>
              <option value="UK">UK</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {/* Cover Letter */}
          <div className="input-group">
            <textarea name="coverLetter" placeholder="Write your cover letter" value={formData.coverLetter} onChange={handleChange} rows={4} required />
          </div>

          {/* File */}
          <div className="file-input-group">
            <label className="file-label">
              <span className="file-button">Choose File</span>
              <span className="file-name">{formData.file ? formData.file.name : "No file chosen"}</span>
              <input type="file" name="file" accept=".pdf,.doc,.docx" onChange={handleChange} />
            </label>
            <p className="file-info">Allowed Type(s): .pdf, .doc, .docx</p>
          </div>

          <button type="submit" className="submit-btn">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default ApplyJobForm;