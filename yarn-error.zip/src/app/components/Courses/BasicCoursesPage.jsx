import React from 'react'

function BasicCoursesPage() {
  return (
    <div>
      basic
    </div>
  )
}

export default BasicCoursesPage
