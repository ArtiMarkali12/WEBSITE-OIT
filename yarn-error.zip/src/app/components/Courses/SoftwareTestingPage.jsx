import React from 'react'

function SoftwareTestingPage() {
  return (
    <div>
      software
    </div>
  )
}

export default SoftwareTestingPage
