import React from 'react'

function JavaFullStack() {
  return (
    <div>
      Java Full Stack
    </div>
  )
}

export default JavaFullStack
