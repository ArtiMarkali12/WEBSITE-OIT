import React from 'react'

function FrontendDevelopmentPage() {
  return (
    <div>
      frontend
    </div>
  )
}

export default FrontendDevelopmentPage
