export const video = {
    mission: {
        background: "images/vid-3-bg.jpg"
    },
    pricing: {
        background: "images/vid-4-bg.jpg"
    }
}